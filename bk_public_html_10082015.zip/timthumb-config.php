<?php

define ('FILE_CACHE_DIRECTORY', './../data/cache/timthumb');
define ('LOCAL_FILE_BASE_DIRECTORY', './');
define ('MAX_WIDTH', 2000);
define ('MAX_HEIGHT', 2000);