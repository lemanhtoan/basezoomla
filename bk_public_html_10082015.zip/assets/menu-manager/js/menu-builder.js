$(function() {
    $('.menu-form-container .save-menu').click(function(e) {
        e.preventDefault();
        var saveButton = $(this);
        var form = $('.menu-form-container #Menu');

        saveButton.includeAjaxLoading();
        $('input[name="serialized"]').val(JSON.stringify($('.menu-form-list').nestable('serialize')));

        $.ajax({
            url: MENUBUILDER.saveUrl,
            type: 'post',
            data: QWeb.formInputs(form),
            dataType: 'json',
            success: function(response) {
                if (typeof(response.data.redirect) != 'undefined') {
                    window.location.href = response.data.redirect;
                }

                saveButton.removeAjaxLoading();

                $.each(response.data.htmls, function(index, value) {
                    $li = $('.menu-form-li[data-id="'+index+'"]');
                    MENUBUILDER.updateLiHtml($li, value);
                });
                
                $('html,body').animate({
                    scrollTop: $('.menu-form-li.error').first().offset().top},
                    'slow'
                );
            }
        });
        
        return false;
    });
    
    $('.menu-types .menu-add').click(function() {
        var $self = $(this);
        var $oldClass = $self.attr('class');
        $self.attr('class', 'fa fa-circle-o-notch fa-spin fa-fw');
        MENUBUILDER.addToList($(this).attr('data-menu-type'), function() {
            $self.attr('class', $oldClass);
        });
    });
    
    $('.menu-form-list').on('click', '.item-edit', function() {
        var $li = $(this).parents('.menu-form-li:first');
        $li.toggleClass('active');
        $('.menu-item-settings', $li).first().slideToggle(200);
    });
    
    $('.menu-form-list').on('click', '.settings-remove', function() {
        var $li = $(this).parents('.menu-form-li:first');
        $li.remove();
    });
    
    $('.menu-form-list').on('click', '.settings-update', function() {
        var $li = $(this).parents('.menu-form-li:first');
        var $id = $li.attr('data-id');
        
        $.ajax({
            url: MENUBUILDER.itemUrl + '?_=' + new Date().getTime() + '&id=' + $id,
            type: 'post',
            data: QWeb.formInputs($li),
            dataType: 'html',
            success: function(data) {
                MENUBUILDER.updateLiHtml($li, data);
            }
        });
    });
});

if (typeof MENUBUILDER === "undefined") {
    MENUBUILDER = {};
}

/**
 * Add a item to menu.
 * 
 * @param string type
 * @return MENUBUILDER
 */
MENUBUILDER.addToList = function(type, callback)
{
    $.ajax({
        url: MENUBUILDER.itemUrl,
        dataType: 'html',
        data: {type: type},
        success: function(data) {
            $('.menu-form-ul:first').append(data);
            var $li = $('.menu-form-list .menu-form-li').last();

            //APP.onAfterAjaxLoad($li);
            
            $('html,body').animate({
                scrollTop: $li.offset().top},
                'slow'
            );
            
            if (typeof(callback) != 'undefined') {
                callback();
            }
        }
    });
}

MENUBUILDER.updateLiHtml = function(element, html) {
    html = $(html);
    $('.menu-item-handle', element).first().replaceWith($('.menu-item-handle', html));
    $('.item-edit', element).first().replaceWith($('.item-edit', html));
    $('.menu-item-settings', element).first().replaceWith($('.menu-item-settings', html));
    element.attr('class', html.attr('class'));
    //APP.onAfterAjaxLoad(element);
}