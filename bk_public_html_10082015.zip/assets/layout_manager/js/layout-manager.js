$(function() {
    var $activeBlock;

    $.fn.setIsActiveBlock = function () {
        $activeBlock = $(this);
        $('.l-block').removeClass('active');
        $activeBlock.addClass('active');
    };

    $.fn.addContainer = function(size, eId, eClass) {
        if (typeof size === 'undefined') {
            var size = 12;
        }
        if (typeof eId === 'undefined') {
            var eId = '';
        }
        if (typeof eClass === 'undefined') {
            var eClass = '';
        }

        var html = '<div class="l-block col-md-'+size+'" data-id="'+eId+'" data-class="'+eClass+'"><div class="container-fluid">';
        html += '<div class="layout-buttons">';
        html += '<span class="title">' + (eId.length ? '#'+eId : '') + '</span>';
        html += '<a href="javascript:;" class="block-edit">Edit</a>&nbsp;&nbsp;';
        html += '<a href="javascript:;" class="add-container">Add container</a>&nbsp;&nbsp;';
        html += '<a href="javascript:;" class="add-widget">Add widget</a>&nbsp;&nbsp;';
        html += '<a href="javascript:;" class="block-remove">Remove</a>';
        html += '</div>';
        html += '<div class="l-container row sortable connected-sortable"></div></div></div>';

        $(this).append(html);
        $('.sortable', $(this)).sortable({
            connectWith: ".connected-sortable",
            placeholder: "ui-state-highlight block-placeholder col-md-4"
        });

        return $(this).children('.l-block:last').find('.l-container:last');
    };

    $.fn.addWidget = function(name, callback) {
        var $self = $(this);

        $.ajax({
            url: QWeb.baseUrl + 'layout-manager/layout/ajax-add-widget',
            dataType: 'html',
            data: {name: name},
            success: function(data) {
                $self.append('<div class="l-block col-md-12">' + data + '</div>');

                var $block = $self.find('.l-block:last');
                afterDOMChange($block);
                QWeb.onAfterAjaxLoad($block);

                if (typeof(callback) != 'undefined') {
                    callback();
                }
            }
        });
    };

    $.fn.addWidgetByHtml = function(html, size, callback) {
        if (typeof size === 'undefined') {
            var size = 12;
        }

        $(this).append('<div class="l-block col-md-' + size + '">' + html + '</div>');

        var $block = $(this).find('.l-block:last');
        afterDOMChange($block);

        if (typeof(callback) != 'undefined') {
            callback();
        }
    };

    $.fn.initializeLayout = function(data) {
        var $container = $(this);
        $.each(data, function(index, value) {
            if (value['type'] == 'container') {
                $childContainer = $container.addContainer(value['size'], value['id'], value['class']);
                $childContainer.initializeLayout(value['children']);
            } else {
                $container.addWidgetByHtml(value['html'], value['size']);
            }
        });
    };

    $.fn.determineSize = function() {
        if (! $(this).length) {
            return 12;
        }

        var elementClass = $(this).attr('class');

        var n = elementClass.indexOf("col-md-");
        elementClass = elementClass.substring(n + 7);
        n = elementClass.indexOf(" ");
        if (n > 0) {
            return parseInt(elementClass.substring(0, n));
        }
        return parseInt(elementClass);
    }

    $.fn.serializeWidget = function() {
        var $block = $(this).parents('.l-block:first');
        return {
            type: 'widget',
            widgetId: $(this).attr('data-id'),
            size: $block.determineSize()
        };
    };

    $.fn.serializeContainer = function() {
        var $self = $(this);
        var children = [];

        $self.find('> .l-block').each(function() {
            var $firstChild = $(this).children().first();
            if ($firstChild.hasClass('l-widget')) {
                children.push($firstChild.serializeWidget());
            } else {
                children.push($firstChild.children('.l-container').first().serializeContainer());
            }
        });

        var $block = $self.parents('.l-block:first');
        if (! $block.length) {
            return children;
        }

        return {
            type: 'container',
            'id': $block.attr('data-id'),
            'class': $block.attr('data-class'),
            size: $block.determineSize(),
            children: children
        };
    };

    var afterDOMChange = function($element) {
        $('.widget-modal', $element).on('show.bs.modal', function (e) {
            $('.sortable').sortable('disable');
        });
        $('.widget-modal', $element).on('hide.bs.modal', function (e) {
            $('.sortable').sortable('enable');

            if ($(this).attr('data-skip-backup')) {
                $(this).attr('data-skip-backup', '');
                return true;
            }

            var backup = $(this).attr('data-backup');
            if (backup) {
                var $body = $('.modal-body', $(this));
                //$('.tinymce', $body).each(function() {
                //    tinymce.get($(this).attr('name')).remove();
                //});
                $body.html(backup);
                QWeb.onAfterAjaxLoad($body);
            }
        });
    };

    $(document).on('click', '.layout-wrapper .add-widget', function() {
        $(this).parents('.l-block:first').setIsActiveBlock();
        $('#widget-list-modal').modal('show');
    });

    $(document).on('click', '.l-block', function(e) {
        $(this).setIsActiveBlock();
        e.stopPropagation();
    });

    $(document).keydown(function(e) {
        if (! $activeBlock) {
            return;
        }

        switch(e.which) {
            case 37: // move block to left
            case 38: // move block up
                $prevBlock = $activeBlock.prev('.l-block');
                if ($prevBlock.length) {
                    $activeBlock.insertBefore($prevBlock);
                }
                break;

            case 39: // move block to right
            case 40: // move block down
                $nextBlock = $activeBlock.next('.l-block');
                if ($nextBlock.length) {
                    $activeBlock.insertAfter($nextBlock);
                }
                break;

            default: return; // exit this handler for other keys
        }
        e.preventDefault(); // prevent the default action (scroll / move caret)
    });

    $('.widget-select').click(function() {
        var $self = $(this);
        var widgetName = $self.data('widget-name');
        var oldClass = $self.attr('class');

        $self.attr('class', 'fa fa-circle-o-notch fa-spin fa-fw');
        if (! $activeBlock.length) {
            var $target = $('.layout-container');
        } else {
            var $target = $('.l-container:last', $activeBlock);
        }

        $target.addWidget(widgetName, function() {
            $('#widget-list-modal').modal('hide');
            $self.attr('class', oldClass);
        });
    });

    $(document).on('click', '.layout-wrapper .add-container', function() {
        var $container = $(this).parent().next();
        $container.addContainer();
    });

    $(document).on('click', '.layout-wrapper .block-remove', function() {
        var $block = $(this).parents('.l-block').first();
        $block.remove();
    });

    $(document).on('click', '.layout-wrapper .block-resize', function() {
        var $block = $(this).parents('.l-block:first');
        bootbox.prompt("Enter widget size from 1 to 12", function(result) {
            result = parseInt(result);
            if (result > 0 && result < 13) {
                for (i = 1; i < 13; i++) {
                    $block.removeClass('col-md-' + i);
                }
                $block.addClass('col-md-' + result);
            }
        });
    });

    $(document).on('click', '.layout-wrapper .block-edit', function() {
        var $block = $(this).parents('.l-block:first');
        var $sizeInput = $('#block-size');
        var $idInput = $('#block-id');
        var $classInput = $('#block-class');
        var $modal = $('#block-edit-modal');

        $sizeInput.val($block.determineSize());
        $idInput.val($block.attr('data-id'));
        $classInput.val($block.attr('data-class'));
        $modal.modal('show');

        $('#block-edit-form').unbind('submit').submit(function(e) {
            e.preventDefault();
            var eId = $idInput.val();
            $block.attr('data-id', eId);
            $block.attr('data-class', $classInput.val());
            var size = parseInt($sizeInput.val());
            if (size > 0 && size < 13) {
                for (i = 1; i < 13; i++) {
                    $block.removeClass('col-md-' + i);
                }
                $block.addClass('col-md-' + size);
            }

            $block.find('> .container-fluid > .layout-buttons > .title').text(eId.length ? '#'+eId : '');

            $modal.modal('hide');
        });
    });

    $('#block-edit-modal').on('shown.bs.modal', function() {
        $('#block-size').focus().select();
    });

    /*$(document).on('click', '.layout-wrapper .widget-clone', function() {
        var $block = $(this).parents('.l-block:first');
        $block.after($block[0].outerHTML);
        var $clonedBlock = $block.next();
        afterDOMChange($clonedBlock);
        QWeb.onAfterAjaxLoad($clonedBlock);
    });*/

    $(document).on('click', '.layout-wrapper .widget-save', function(e) {
        e.preventDefault();
        var $saveButton = $(this);
        var $widget = $saveButton.parents('.l-widget:first');

        $saveButton.includeAjaxLoading();

        $.ajax({
            url: QWeb.baseUrl + 'layout-manager/layout/ajax-validate',
            type: 'post',
            data: QWeb.formInputs($widget),
            dataType: 'json',
            success: function(response) {
                var $html = $(response.data.html);

                var newModalBody = $html.find('.modal-body').html();
                if (response.status == 'success') {
                    $widget.attr('class', $html.attr('class'));
                    $widget.find('.widget-modal')
                        .attr('data-backup', newModalBody)
                        .attr('data-skip-backup', 1)
                        .modal('hide');
                }

                $widget.find('.modal-body').html(newModalBody);
                QWeb.onAfterAjaxLoad($widget.find('.modal-body'));
                $widget.find('.l-title').html($html.find('.l-title').html());

                $saveButton.removeAjaxLoading();
            }
        });
    });

    $('.save-layout').click(function() {
        var $saveButton = $(this);
        var $root = $('.layout-container');

        $saveButton.includeAjaxLoading();

        // serialize layout structure
        var data = $root.serializeContainer();

        $('input[name="serialized"]').val(JSON.stringify(data));

        $.ajax({
            url: QWeb.baseUrl + 'layout-manager/layout/ajax-save',
            type: 'post',
            data: QWeb.formInputs($('.layout-wrapper')),
            dataType: 'json',
            success: function(response) {
                if (typeof(response.data.redirect) != 'undefined') {
                    window.location.href = response.data.redirect;
                }

                $.each(response.data.htmls, function(index, value) {
                    $widget = $('.l-widget[data-id="'+index+'"]');
                    var $html = $(value);
                    $widget.html($html.html());
                    $widget.attr('class', $html.attr('class'));
                });

                afterDOMChange($root);
                QWeb.onAfterAjaxLoad($root);

                $saveButton.removeAjaxLoading();

                if (response.status != 'success') {
                    bootbox.alert("Please complete all widget settings that have red box", function() {
                        $('html,body').animate({
                                scrollTop: $('.l-widget.panel-danger').first().offset().top},
                            'slow'
                        );
                    });
                }
            }
        });

        return false;
    });

    $('#layout-edit-form').submit(function(e) {
        e.preventDefault();
        var $container = $('#layout-edit-modal');
        var $updateButton = $('#layout-edit-button');
        $updateButton.includeAjaxLoading();

        $.ajax({
            url: QWeb.baseUrl + 'layout-manager/layout/edit/' + $('#layout-element').val(),
            type: 'post',
            data: QWeb.formInputs($(this)),
            dataType: 'json',
            success: function(response) {
                $updateButton.removeAjaxLoading();

                if (response.status == 'success') {
                    $container.modal('hide');
                    return;
                }
            }
        });
    });

    $('#layout-element').change(function(e) {
        window.location.href = QWeb.baseUrl + 'layout-manager?id=' + $(this).val();
    });
});